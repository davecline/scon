export const steps = [
    {
        "step_id":1,
        "name":"Step One"
    },
    {
        "step_id":2,
        "name":"Step Two"
    }
]